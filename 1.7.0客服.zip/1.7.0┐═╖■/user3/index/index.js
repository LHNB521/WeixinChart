//index.js
//获取应用实例
const app = getApp()

Page({
  
  data: {
    message: "进入客服会话",
    hiddenmodalput: true,
    name:'',
  },
  onLoad: function () {
   
  },

  modalinput: function () {
    this.setData({
      hiddenmodalput: !this.data.hiddenmodalput
    })
  },
  //取消按钮
  off: function () {
    this.setData({
      hiddenmodalput: true
    });
  },
  //获取输入框的名字
  nameInput: function (e) {
    this.setData({
      name: e.detail.value,
    });
  },

  //确认
  chat: function () {
    var id=this.data.name
    if (this.data.name==""){
      wx.showToast({
        title: '消息不能为空哦',
      })
    }else{
      this.setData({
        hiddenmodalput: true
      })
      wx.navigateTo({
        url: '../chat/chat?id=' + id,
      })
    }
  }
  

})
