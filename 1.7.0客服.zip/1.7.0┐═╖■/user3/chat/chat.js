//index.js
//获取应用实例
const app = getApp()
// socket 连接插件
import io from '../weapp.socket.io.js'
// const io = require('../weapp.socket.io.js')
//链接地址
var socketurl = 'ws://127.0.0.1:3000'
var that

Page({
  data: {
    use: [],
    newbool: true,
    newslist: [],
    txt: [{
      speaker: '',
      content: '欢迎'
    }],
    messages: [],
    inputMarBot: false,
    name: [],
    name1: [],
  },
 
  /*周期函数*/
  onLoad: function(a) {
    var name1 = [];
    that = this
    that.setData({
      name: a.id
    })
    var a = wx.getStorageSync('name')
    console.log(a[0]);
    for (var x in a) {
      name1.push(a[x])
    }
    console.log(this.data.name)
    for (var x in a) {
      if (a[x] == this.data.name) {
        if (wx.getStorageSync(this.data.name) == '') {
          wx.showToast({
            title: '没有聊天记录',
          })
        } else {
          this.setData({
            txt: wx.getStorageSync(this.data.name)
          })
        };
      }
    }
    name1.push(this.data.name)
    wx.setStorageSync('name', name1);
    this.socketstart();

  },


  /*socket链接走起--*/
  socketstart: function() {
    //设置链接地址
    var id = this.data.name;
    const socket = (this.socket = io(socketurl))
    socket.on('connect', function(s) {
      socket.emit('message2', id)
      wx.showToast({
        title: '链接成功!',
      })
    });
    socket.on('message1', function(d) {
      that.receive(d);
    })
    socket.on('message4', function(d) {
      that.receive(d);
    })
  },

  

  /*** 接收消息*/
  receive: function(d) {
    var obj = {}
    obj.speaker = "server"
    obj.content = d
    let txt = that.data.txt
    txt.push(obj)
    that.setData({
      txt
    })
  },

  InputFocus: function() {
    this.setData({
      inputMarBot: true
    })
  },
  InputBlur: function() {
    this.setData({
      inputMarBot: false
    })
  },

  //获取输入框的内容
  userInput: function(e) {
    this.setData({
      use: e.detail.value,
    });

  },

  //事件处理函数
  send: function() {
    var that = this
    var obj = {}
    if (this.data.use == "") {
      wx.showToast({
        title: '消息不能为空哦',
      })
    } else {
      this.socket.emit('message', this.data.use)
      wx.setStorageSync('key', this.data.use);
      var a = wx.getStorageSync('key');
      console.log(a);
      obj.speaker = "user"
      obj.content = this.data.use
      let txt = that.data.txt
      txt.push(obj)
      that.setData({
        txt
      })
      console.log(that.data.txt)
      console.log(obj.content)
      wx.setStorageSync(this.data.name, this.data.txt);
      this.setData({
        use: ''
      });
    }
  },

  // 用户点击右上角分享

  onShareAppMessage: function() {

  }
})