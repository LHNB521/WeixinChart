//index.js
//获取应用实例
const app = getApp()



Page({
  
  data: {
    message: "进入客服会话",
    
  },

  chat: function (options) {
    wx.redirectTo({
      url: '../chat/chat'
    })
  },


  

 /* chat: function (even) {
    wx.connectSocket({
      url: 'ws://localhost:3000/',
      method: 'POST',
      success: function () {
        isConnect: true
        console.log("连接成功...")
    
        wx.redirectTo({
          url: '../chat/chat'
        })
      },
      fail: function () {
        isConnect: false
        console.log("连接失败...")
      }
    })
  },
*/
})
