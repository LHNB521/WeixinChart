//index.js
//获取应用实例
const app = getApp()
// socket 连接插件
const io = require('../weapp.socket.io.js')
//链接地址
var socketurl ='ws://127.0.0.1:3000'
var that
// import io from '../socket.io.xcx.min'
// let socket = io('ws://127.0.0.1:3000')
// var message=new Array()
// function setup() {
//   let socket = io('ws://127.0.0.1:3000')
//   var message = new Array()
//   socket.on('message', function (d) {
//     wx.setStorageSync('new', d)
//     console.log(d);  
//   })
//   socket.on('connect', function() {
//     console.log('连上了');
//   });
// };


Page({
  data: {
    use: [],
    newbool: true,
    newslist: [],
    txt: [], //输入框默认为空
    messages: [],
  },

  onLoad: function() {
    // setup.apply(this);
    // if (wx.getStorageSync('new') == '') {
    //   wx.showToast({
    //     title: '没有聊天记录',
    //   })
    // } else {
    //   this.setData({
    //     messages: wx.getStorageSync('new')
    //   })
    // };
  that=this
  this.socketstart();
    
  if (wx.getStorageSync('chat')==''){
      wx.showToast({
        title: '没有聊天记录',
      })
    }else{
      this.setData({
        txt: wx.getStorageSync('chat')
      })
    };

    if (wx.getStorageSync('kf1') == '') {
      wx.showToast({
        title: '没有聊天记录',
      })
    } else {
      this.setData({
        messages: wx.getStorageSync('kf1')
      })
    };


  },
  

  /*socket链接走起--*/
  socketstart: function(){
    //设置链接地址
   const socket =(this.socket=io(socketurl))
    socket.on('connect', () =>{
      console.log("链接上了")
    });
    socket.on('message1',function(d){
      that.receive(d);
    })
    
  },

  /*** 接收消息*/
  receive: function (d) {
    // this.setData({
    //   messages: d
    // });
    // wx.setStorageSync('kf', d);
    // var a = wx.getStorageSync('kf');
    // console.log(a);
    this.setData({
      messages: this.data.messages.concat(d)
    })
  
    wx.setStorageSync('kf1', this.data.messages);
  },


  //获取输入框的内容
  userInput: function(e) {
    this.setData({
      use: e.detail.value,
    });
    
  },
 
  //事件处理函数
  send: function() {
  if (this.data.use == "") {
      wx.showToast({
        title: '消息不能为空哦',
      })
    } else {
      this.socket.emit('message', this.data.use)
      wx.setStorageSync('key', this.data.use);
      var a = wx.getStorageSync('key');
      console.log(a);
      this.setData({
        txt:this.data.txt.concat(a)
      })
      console.log(this.data.txt)
      wx.setStorageSync('chat', this.data.txt);
      this.setData({
        use: ''
      });

   
    }
  },
 
// 用户点击右上角分享

  onShareAppMessage: function() {

  }
})