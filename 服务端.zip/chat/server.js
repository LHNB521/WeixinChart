//创建一个服务器http://127.0.0.1:3000
var app = require('http').createServer();//引入http模块，并创建
var io = require('socket.io')(app);//引入socket.io模块
var PORT = 3000;//端口
var people= 0;//在线人数，0是客服
app.listen(PORT);//监听

io.on('connection',function(socket){
	
	if(people==0){
		var user='客服'
		socket.nickname = user;
	}else{
		var user='用户'
		socket.nickname = user+people;
	}
	people++;
	io.emit('enter'," 欢迎"+socket.nickname);//emit发送消息

	socket.on('message',function(str){
		io.emit('message',socket.nickname+' 说: '+str)
	})

	socket.on('disconnect',function(){
		io.emit('left',socket.nickname+" 下线")
	})
})

console.log("正在监听:"+PORT)